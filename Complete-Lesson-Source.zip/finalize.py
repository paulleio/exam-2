"""Join video sections with continuous original PCM audio (no AAC join artifacts)."""
from pathlib import Path
import json,wave,subprocess,os
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'

def label(row):
    if row['problem']==0:return 'Introduction: '+row['title']
    if row['problem']==53:return 'Closing review: '+row['title']
    return f"Problem {row['problem']}: {row['title']}"

def metadata(rows,end,offset=0):
    ch=[]
    for row in rows:
        if not ch or ch[-1]['title']!=row['title']:ch.append(row)
    lines=[';FFMETADATA1','title=Complete Exam 2 Calculus Study Guide']
    for i,row in enumerate(ch):
        stop=ch[i+1]['start'] if i+1<len(ch) else end
        lines+=['[CHAPTER]','TIMEBASE=1/1000',f"START={round((row['start']-offset)*1000)}",f'END={round((stop-offset)*1000)}','title='+label(row)]
    return '\n'.join(lines)+'\n'

def main():
    timeline=json.loads((OUT/'timeline.json').read_text());end=sum(r['duration'] for r in timeline)
    for part in range(1,6):
        rows=[r for r in timeline if r['part']==part];offset=rows[0]['start'];stop=offset+sum(r['duration'] for r in rows)
        meta=ROOT/f'part{part}.ffmeta';meta.write_text(metadata(rows,stop,offset))
        original=OUT/f'Exam2-Full-Part-{part}.mp4';temp=OUT/f'part-{part}-chapters.tmp.mp4'
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(original),'-f','ffmetadata','-i',str(meta),'-map','0:v','-map','0:a','-map','0:s','-map_metadata','1','-map_chapters','1','-c','copy','-movflags','+faststart',str(temp)],check=True)
        os.replace(temp,original)
    with wave.open(str(ROOT/'complete-narration.wav'),'wb') as out:
        out.setnchannels(1);out.setsampwidth(2);out.setframerate(22050)
        for part in range(1,6):
            with wave.open(str(ROOT/f'part{part}.wav'),'rb') as w:
                assert w.getframerate()==22050 and w.getnchannels()==1
                while data:=w.readframes(22050*30):out.writeframes(data)
    (ROOT/'full.ffmeta').write_text(metadata(timeline,end))
    files=[OUT/f'Exam2-Full-Part-{part}.mp4' for part in range(1,6)]
    (ROOT/'parts.txt').write_text('\n'.join(f"file '{p}'" for p in files)+'\n')
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','concat','-safe','0','-i',str(ROOT/'parts.txt'),'-i',str(ROOT/'complete-narration.wav'),'-i',str(OUT/'Complete-Captions.srt'),'-f','ffmetadata','-i',str(ROOT/'full.ffmeta'),'-map','0:v','-map','1:a','-map','2:s','-map_metadata','3','-map_chapters','3','-c:v','copy','-af','loudnorm=I=-16:TP=-1.5:LRA=7','-ar','44100','-c:a','aac','-b:a','96k','-c:s','mov_text','-movflags','+faststart','-t',str(end),str(OUT/'Exam2-Complete-Clear-Voice.mp4')],check=True)
    print('Continuous-audio full video assembled; chapter labels cleaned.',flush=True)

if __name__=='__main__':main()
