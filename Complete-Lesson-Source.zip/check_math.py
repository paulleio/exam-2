"""Independent symbolic and numerical checks of worked answers."""
import sympy as s
import json
from pathlib import Path
x,t,u,k,y=s.symbols('x t u k y',real=True)
checks=[]
def check(n,f,answer,var=x,order=1):
    residual=s.trigsimp(s.simplify(s.diff(f,var,order)-answer))
    if residual!=0:
        residual=s.trigsimp(s.simplify(s.diff(f,var,order)/f-answer/f))
    assert residual==0,(n,residual)
    checks.append(n)
check(2,x*x-10*x+100,2*x-10);check('2 second',x*x-10*x+100,2,order=2)
check(3,s.sin(x)+s.cos(x),s.cos(x)-s.sin(x));check('3 second',s.sin(x)+s.cos(x),-s.sin(x)-s.cos(x),order=2)
check(4,(16*x)**3,12288*x*x)
check(5,s.cos(x)-2*s.tan(x),-s.sin(x)-2/s.cos(x)**2)
check('5 second',s.cos(x)-2*s.tan(x),-s.cos(x)-4*s.tan(x)/s.cos(x)**2,order=2)
check(6,x*x+x**-2,2*x-2*x**-3);check('6 second',x*x+x**-2,2+6*x**-4,order=2)
check(7,s.tan(x)/x,(x/s.cos(x)**2-s.tan(x))/x**2)
check(9,s.sin(x)/(1+s.cos(x)),1/(1+s.cos(x)))
check(10,(2*x-3)*s.log(3*x*x+4),2*s.log(3*x*x+4)+(2*x-3)*6*x/(3*x*x+4))
check(11,s.exp(2*x)*s.atan(x/2),s.exp(2*x)*(2*s.atan(x/2)+2/(x*x+4)))
check(12,s.asin(x*x-1),2*x/s.sqrt(1-(x*x-1)**2))
check(13,s.tan(x)*(s.sin(x)+s.cos(x)),(s.sin(x)+s.cos(x))/s.cos(x)**2+s.tan(x)*(s.cos(x)-s.sin(x)))
check(14,(x+2)/(x-1),-3/(x-1)**2);check('14 second',(x+2)/(x-1),6/(x-1)**3,order=2)
check(15,s.csc(x)*s.cot(x),-s.csc(x)*s.cot(x)**2-s.csc(x)**3)
check('15 second',s.csc(x)*s.cot(x),s.csc(x)*s.cot(x)**3+5*s.csc(x)**3*s.cot(x),order=2)
check(16,(1-u*u)/(1+u*u),-4*u/(1+u*u)**2,u)
check(17,s.sqrt(x*x-7*x),(2*x-7)/(2*s.sqrt(x*x-7*x)))
check(18,x**s.Rational(3,2)+x**s.Rational(-5,2),s.Rational(3,2)*s.sqrt(x)-s.Rational(5,2)*x**s.Rational(-7,2))
check(19,(t-1/t)**s.Rational(3,2),s.Rational(3,2)*s.sqrt(t-1/t)*(1+1/t**2),t)
check(20,(x**3-5*x)**4,4*(x**3-5*x)**3*(3*x*x-5))
check(21,(6*t*t+5)**3*(t**3-7)**4,12*t*(6*t*t+5)**2*(t**3-7)**3*(3*(t**3-7)+t*(6*t*t+5)),t)
check(22,((y-6)/(y+7))**3,39*(y-6)**2/(y+7)**4,y)
check(23,s.sqrt(s.exp(4*x)-s.exp(x*x)),(4*s.exp(4*x)-2*x*s.exp(x*x))/(2*s.sqrt(s.exp(4*x)-s.exp(x*x))))
check(24,s.sin(x)**3+s.cos(x)**3,3*s.sin(x)*s.cos(x)*(s.sin(x)-s.cos(x)))
check(25,s.sin(s.cos(k*x))**2,-2*k*s.sin(s.cos(k*x))*s.cos(s.cos(k*x))*s.sin(k*x))
check(26,x*s.sinh(x*x),s.sinh(x*x)+2*x*x*s.cosh(x*x))
check(27,s.log(s.cosh(3*x)),3*s.tanh(3*x))
for n,F,yp in [(28,y**5+3*x*x*y*y+5*x**4-12,-(6*x*y*y+20*x**3)/(5*y**4+6*x*x*y)),(29,x**4+y**4-16,-x**3/y**3),(31,x*s.cos(y)+y*s.cos(x)-1,(y*s.sin(x)-s.cos(y))/(s.cos(x)-x*s.sin(y)))]:
    assert s.simplify(s.diff(F,x)+s.diff(F,y)*yp)==0,n
    checks.append(n)
yp=-x**3/y**3;ypp=s.diff(yp,x)+s.diff(yp,y)*yp
assert s.simplify(ypp+3*x*x/y**3+3*x**6/y**7)==0
assert s.simplify((ypp+48*x*x/y**7)*y**7).subs(y**4,16-x**4).expand()==0
check(30,(x**3+x)/(x*x+2),(x**4+5*x*x+2)/(x*x+2)**2)
check(32,(2*x**3-4)**(x*x),(2*x**3-4)**(x*x)*(2*x*s.log(2*x**3-4)+6*x**4/(2*x**3-4)))
check(33,s.tan(x)**s.sin(x),s.tan(x)**s.sin(x)*(s.cos(x)*s.log(s.tan(x))+s.sec(x)))
tangents=[(34,x/(x-3),6,2,-s.Rational(1,3)),(35,2*s.sin(x),s.pi/6,1,s.sqrt(3)),(36,s.sin(x)+s.cos(2*x),s.pi/6,1,-s.sqrt(3)/2),(37,x/(3-x*x)**5,2,-2,39)]
for n,f,a,b,m in tangents:
    assert s.simplify(f.subs(x,a)-b)==0
    assert s.simplify(s.diff(f,x).subs(x,a)-m)==0
    checks.append(n)
assert s.Rational(9)*(-5)/(16*s.Rational(9,4))==-s.Rational(5,4)
assert (6-4)/2==1
for n,pos,roots,az in [(40,2*t**3-9*t*t+12*t+1,[1,2],s.Rational(3,2)),(41,4*t**3-9*t*t+6*t+2,[s.Rational(1,2),1],s.Rational(3,4))]:
    v=s.diff(pos,t);a=s.diff(v,t)
    assert s.solve(v,t)==roots and s.solve(a,t)==[az]
    times=[roots[0]/2,(roots[0]+az)/2,(az+roots[1])/2,roots[1]+1]
    assert [s.sign(v.subs(t,z)*a.subs(t,z)) for z in times]==[-1,1,-1,1]
    checks.append(n)
assert s.Rational(12)*30*s.Rational(10,2700)==s.Rational(4,3)
assert s.Rational(4,20)/(1+s.Rational(15,20)**2)==s.Rational(16,125)
assert -400*s.csc(s.pi/6)**2*(-s.Rational(1,4))==400
assert 4+s.Rational(1,8)*s.Rational(1,100)==s.Rational(400125,100000)
assert 16+32*(-s.Rational(1,1000))==s.Rational(15968,1000)
assert (3*2**2-4*2)*s.Rational(2,10)==s.Rational(8,10)
assert 3*30**2*s.Rational(1,10)==270
assert 12*30*s.Rational(1,10)==36
data=json.loads((Path(__file__).parent/'lesson.json').read_text())
assert set(range(1,53)) <= {c['number'] for c in data}
print(f'PASS: {len(checks)} symbolic derivative, tangent, and motion checks; all 52 problem numbers present. Additional rates and approximation checks passed.')
