"""Verify completed encoded outputs, durations, subtitles, and coverage."""
import json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'
data=json.loads((ROOT/'lesson.json').read_text())
assert set(range(1,53)) <= {c['number'] for c in data}
for number,letters in [(1,'abcdefghijklmnopqrstu'),(52,'abcdefghij')]:
    present=set()
    for c in data:
        if c['number']==number:
            for eq,narr in c['steps']:present.update(re.findall(r'\(([a-u])\)',eq))
    assert set(letters)<=present,(number,set(letters)-present)
timeline=json.loads((OUT/'timeline.json').read_text())
assert len(timeline)==sum(len(c['steps']) for c in data)==200
report=[]
for part in range(1,6):
    path=OUT/f'Exam2-Full-Part-{part}.mp4'
    expected=sum(s['duration'] for s in timeline if s['part']==part)
    r=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-show_chapters','-of','json',str(path)],capture_output=True,text=True,check=True)
    d=json.loads(r.stdout);video=next(s for s in d['streams'] if s['codec_type']=='video');audio=next(s for s in d['streams'] if s['codec_type']=='audio')
    assert video['width']==1280 and video['height']==720
    assert any(s['codec_type']=='subtitle' for s in d['streams'])
    assert d['chapters']
    assert abs(float(video['duration'])-expected)<.25,(part,video['duration'],expected)
    assert abs(float(audio['duration'])-expected)<.25,(part,audio['duration'],expected)
    assert abs(float(video['duration'])-float(audio['duration']))<.25
    subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(path),'-map','0:v','-map','0:a','-f','null','-'],check=True)
    report.append(dict(part=part,minutes=round(expected/60,2),bytes=path.stat().st_size,decode='passed'))
full=OUT/'Exam2-Complete-Clear-Voice.mp4'
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-show_chapters','-of','json',str(full)],text=True))
expected=sum(s['duration'] for s in timeline)
for typ in ['video','audio']:
    stream=next(s for s in d['streams'] if s['codec_type']==typ)
    assert abs(float(stream['duration'])-expected)<1.5,(typ,stream['duration'],expected)
assert len(d['chapters'])==len(data)
assert full.stat().st_size<100*1024*1024,'Use the five checked parts if the combined file exceeds GitHub size limits.'
subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(full),'-map','0:v','-map','0:a','-f','null','-'],check=True)
result=dict(problem_numbers=52,lettered_subparts='1(a-u), 52(a-j)',steps=200,chapters=len(d['chapters']),minutes=round(expected/60,2),combined_bytes=full.stat().st_size,parts=report,decode='all passed')
(OUT/'video-validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
