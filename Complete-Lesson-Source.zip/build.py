"""Render complete study-guide video with cached neural narration and large captions."""
from pathlib import Path
import os,sys,json,re,io,wave,hashlib,threading,concurrent.futures,subprocess,textwrap,functools,time
ROOT=Path(__file__).resolve().parent
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'mpl-cache'))
os.environ.setdefault('XDG_CACHE_HOME',str(ROOT/'cache'))
from speech import load_voice,CONFIG
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import matplotlib
matplotlib.use('Agg')
from matplotlib import mathtext
from matplotlib.font_manager import FontProperties

DATA=json.loads((ROOT/'lesson.json').read_text())
STEPS=[dict(chapter=c,local=i,equation=e,narration=n) for c in DATA for i,(e,n) in enumerate(c['steps'])]
for i,s in enumerate(STEPS):s['index']=i
for name in ['frames','audio','output','cache']: (ROOT/name).mkdir(exist_ok=True)
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
@functools.lru_cache(None)
def font(size,bold=False):return ImageFont.truetype(BOLD if bold else FONT,size)
WHITE=(237,243,252);BG=(13,23,39);MUTED=(154,173,196);YELLOW=(255,213,94);TEAL=(88,206,214)
@functools.lru_cache(None)
def equation(text):
    if text.startswith('$'):
        buf=io.BytesIO(); mathtext.math_to_image(text,buf,dpi=135,format='png',color='black',prop=FontProperties(size=24))
        buf.seek(0);im=Image.open(buf).convert('RGBA');a=np.asarray(im).copy()
        if a[:,:,3].min()==255:a[:,:,3]=255-np.min(a[:,:,:3],axis=2)
        a[:,:,:3]=WHITE; im=Image.fromarray(a)
        scale=min(1,1110/im.width,65/im.height)
        return im.resize((max(1,round(im.width*scale)),max(1,round(im.height*scale))),Image.Resampling.LANCZOS)
    im=Image.new('RGBA',(1120,75));d=ImageDraw.Draw(im);size=32
    while d.textbbox((0,0),text,font=font(size))[2]>1105:size-=1
    d.text((0,13),text,font=font(size),fill=WHITE)
    return im

tls=threading.local()
def synth(step):
    ident=hashlib.sha256((step['narration']+'lessac-high-v1-1.12').encode()).hexdigest()[:20]
    wav=ROOT/'audio'/f'{ident}.wav';meta=wav.with_suffix('.json')
    if wav.exists() and meta.exists():return json.loads(meta.read_text())|{'wav':str(wav)}
    if not hasattr(tls,'voice'):tls.voice=load_voice()
    v=tls.voice;rate=v.config.sample_rate
    sentences=re.split(r'(?<=[.!?])\s+',step['narration'])
    raw=[];timings=[];elapsed=0
    for text in sentences:
        if not text:continue
        pieces=[c.audio_int16_bytes for c in v.synthesize(text,syn_config=CONFIG)]
        pcm=b''.join(pieces)
        assert pcm,f'Empty speech for {text}'
        secs=len(pcm)/(rate*2)
        timings.append(dict(start=elapsed,end=elapsed+secs,text=text))
        pause=.27
        raw.extend([pcm,b'\0\0'*round(rate*pause)]);elapsed+=secs+pause
    raw.append(b'\0\0'*round(rate*.85));elapsed+=.85
    with wave.open(str(wav)+'.tmp','wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(b''.join(raw))
    os.replace(str(wav)+'.tmp',wav)
    result=dict(duration=elapsed,sentences=timings,rate=rate)
    meta.write_text(json.dumps(result));return result|{'wav':str(wav)}

def caption_chunks(text):
    words=text.split();out=[];cur=[]
    for word in words:
        if cur and len(' '.join(cur+[word]))>112:
            out.append(' '.join(cur));cur=[]
        cur.append(word)
    if cur:out.append(' '.join(cur))
    return out

def stamp(t,ass=False):
    if ass:
        n=round(t*100);sec,cs=divmod(n,100);m,sec=divmod(sec,60);h,m=divmod(m,60)
        return f'{h}:{m:02}:{sec:02}.{cs:02}'
    n=round(t*1000);sec,ms=divmod(n,1000);m,sec=divmod(sec,60);h,m=divmod(m,60)
    return f'{h:02}:{m:02}:{sec:02},{ms:03}'

def frame(step,phase):
    c=step['chapter'];si=step['local'];im=Image.new('RGB',(1280,720),BG);d=ImageDraw.Draw(im)
    d.text((52,24),'COMPLETE CALCULUS / EXAM 2',font=font(18,True),fill=TEAL)
    title=c['title'];size=35
    while d.textbbox((0,0),title,font=font(size,True))[2]>1170:size-=1
    d.text((52,59),title,font=font(size,True),fill=WHITE)
    source=c['source'] if c['number'] not in [0,53] else 'Study-guide walkthrough'
    d.text((54,111),source+f"  •  Part {c['part']} of 5",font=font(20),fill=MUTED)
    start=max(0,si-3)
    for j in range(start,si+1):
        y=163+(j-start)*94;current=j==si
        if current:
            d.rounded_rectangle((37,y-8,1243,y+79),radius=12,fill=(45,49,49),outline=YELLOW,width=2)
            d.rectangle((40,y+7,46,y+63),fill=YELLOW)
        glyph=equation(c['steps'][j][0]).copy()
        if current and phase<3:glyph.putalpha(glyph.getchannel('A').point(lambda a:int(a*(phase+1)/4)))
        im.paste(glyph,(62,y+max(0,(67-glyph.height)//2)),glyph)
    d.text((54,566),f"STEP {si+1} OF {len(c['steps'])}  •  Pause before the next reveal",font=font(18),fill=YELLOW)
    d.rectangle((0,611,1280,704),fill=(5,12,23))
    d.rectangle((0,710,1280,720),fill=(31,46,64));d.rectangle((0,710,int(1280*(step['index']+1)/len(STEPS)),720),fill=TEAL)
    return im

ASS_HEADER='''[Script Info]
ScriptType: v4.00+
PlayResX: 1280
PlayResY: 720
WrapStyle: 0
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,DejaVu Sans,27,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,55,55,27,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''

def main(only_part=None):
    # Validate every equation before spending time on narration.
    for step in STEPS:equation(step['equation'])
    print(f'All {len(STEPS)} equation panels validated.',flush=True)
    speech=[None]*len(STEPS)
    requested=[s for s in STEPS if only_part is None or s['chapter']['part']==only_part]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        futures={ex.submit(synth,s):s['index'] for s in requested}
        for count,f in enumerate(concurrent.futures.as_completed(futures),1):
            i=futures[f];speech[i]=f.result()
            print(f"SPEECH {count}/{len(requested)} | problem {STEPS[i]['chapter']['number']} | {speech[i]['duration']:.1f}s",flush=True)
    transcript=['# Complete Exam 2 Study Guide — Worked Video Lesson','','Source: Exam2StudyGuide.pdf. All 52 numbered problems and their lettered subparts. Neural synthetic narration: Lessac high via Piper.','']
    previous=None
    for s in STEPS:
        c=s['chapter']
        if c is not previous:transcript.extend([f"## {c['source']}: {c['title']}",'']);previous=c
        transcript.extend([s['equation'],'',s['narration'],''])
    (ROOT/'output/Complete-Lesson-Transcript.md').write_text('\n'.join(transcript))
    global_elapsed=0;global_caps=[];global_timeline=[];part_files=[]
    for part in ([only_part] if only_part is not None else range(1,6)):
        chosen=[s for s in STEPS if s['chapter']['part']==part]
        concat=[];captions=[];elapsed=0;chapter_meta=[';FFMETADATA1'];chapter_list=[]
        for s in chosen:
            info=speech[s['index']];c=s['chapter']
            if not chapter_list or chapter_list[-1]['title']!=c['title']:
                chapter_list.append(dict(title=f"{c['source']}: {c['title']}",start=elapsed))
            for phase in range(4):
                path=ROOT/'frames'/f"{s['index']:03}-{phase}.png";frame(s,phase).save(path)
                duration=.08333333 if phase<3 else info['duration']-.25
                concat.extend([f"file '{path}'",f'duration {duration:.8f}'])
            for sentence in info['sentences']:
                blocks=caption_chunks(sentence['text']);lengths=[len(b) for b in blocks];denom=sum(lengths);t=sentence['start']
                for block,length in zip(blocks,lengths):
                    dur=(sentence['end']-sentence['start'])*length/denom
                    captions.append((elapsed+t,elapsed+t+dur,block))
                    global_caps.append((global_elapsed+elapsed+t,global_elapsed+elapsed+t+dur,block));t+=dur
            global_timeline.append(dict(problem=c['number'],title=c['title'],part=part,start=global_elapsed+elapsed,duration=info['duration']))
            elapsed+=info['duration']
        concat.append(concat[-2]);(ROOT/f'part{part}-frames.txt').write_text('\n'.join(concat)+'\n')
        for i,ch in enumerate(chapter_list):
            end=chapter_list[i+1]['start'] if i+1<len(chapter_list) else elapsed
            chapter_meta.extend(['[CHAPTER]','TIMEBASE=1/1000',f"START={round(ch['start']*1000)}",f'END={round(end*1000)}',f"title={ch['title']}"])
        (ROOT/f'part{part}.ffmeta').write_text('\n'.join(chapter_meta)+'\n')
        ass=ASS_HEADER
        for a,b,text in captions:
            text=r'\N'.join(textwrap.wrap(text,width=77))
            ass+=f'Dialogue: 0,{stamp(a,True)},{stamp(b,True)},Default,,0,0,0,,{text}\n'
        (ROOT/f'part{part}.ass').write_text(ass)
        (ROOT/f'output/Part-{part}-Captions.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n{text}' for i,(a,b,text) in enumerate(captions))+'\n')
        rate=speech[chosen[0]['index']]['rate']
        with wave.open(str(ROOT/f'part{part}.wav'),'wb') as out:
            out.setnchannels(1);out.setsampwidth(2);out.setframerate(rate)
            for s in chosen:
                with wave.open(speech[s['index']]['wav'],'rb') as w:out.writeframes(w.readframes(w.getnframes()))
        out=ROOT/f'output/Exam2-Full-Part-{part}.mp4';part_files.append(out)
        print(f'ENCODING PART {part}: {elapsed/60:.1f} minutes',flush=True)
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','concat','-safe','0','-i',str(ROOT/f'part{part}-frames.txt'),'-i',str(ROOT/f'part{part}.wav'),'-i',str(ROOT/f'output/Part-{part}-Captions.srt'),'-f','ffmetadata','-i',str(ROOT/f'part{part}.ffmeta'),'-map','0:v','-map','1:a','-map','2:s','-map_metadata','3','-map_chapters','3','-vf',f"fps=12,ass={ROOT}/part{part}.ass,format=yuv420p",'-af','loudnorm=I=-16:TP=-1.5:LRA=7','-ar','44100','-c:v','libx264','-preset','veryfast','-crf','26','-threads','3','-c:a','aac','-b:a','96k','-c:s','mov_text','-metadata:s:s:0','language=eng','-movflags','+faststart','-t',str(elapsed),str(out)],check=True)
        print(f'FINISHED PART {part}: {out.stat().st_size/1e6:.1f} MB',flush=True)
        global_elapsed+=elapsed
    if only_part is not None:
        print(f'PART {only_part} COMPLETE',flush=True)
        return
    (ROOT/'output/Complete-Captions.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n{text}' for i,(a,b,text) in enumerate(global_caps))+'\n')
    (ROOT/'output/timeline.json').write_text(json.dumps(global_timeline,indent=2))
    metadata=[';FFMETADATA1','title=Complete Exam 2 Calculus Study Guide — Neural Narration']
    chs=[]
    for row in global_timeline:
        if not chs or chs[-1]['title']!=row['title']:chs.append(row)
    for i,ch in enumerate(chs):
        end=chs[i+1]['start'] if i+1<len(chs) else global_elapsed
        metadata.extend(['[CHAPTER]','TIMEBASE=1/1000',f"START={round(ch['start']*1000)}",f'END={round(end*1000)}',f"title=Problem {ch['problem']}: {ch['title']}"])
    (ROOT/'full.ffmeta').write_text('\n'.join(metadata)+'\n')
    (ROOT/'parts.txt').write_text('\n'.join(f"file '{p}'" for p in part_files)+'\n')
    # Remove part subtitle streams during concatenation and supply the global captions.
    from finalize import main as finalize
    finalize()
    print(f'COMPLETE: {global_elapsed/60:.2f} minutes; {len(STEPS)} steps; 52 problems.',flush=True)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--part',type=int,choices=range(1,6))
    main(parser.parse_args().part)
