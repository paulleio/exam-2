import sys, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
import onnxruntime as ort
from piper import PiperVoice,SynthesisConfig
from piper.config import PiperConfig

def load_voice():
    model=ROOT/'voice/vits-piper-en_US-lessac-high/en_US-lessac-high.onnx'
    opts=ort.SessionOptions();opts.intra_op_num_threads=2;opts.inter_op_num_threads=1
    opts.enable_mem_pattern=True
    sess=ort.InferenceSession(str(model),sess_options=opts,providers=['CPUExecutionProvider'])
    return PiperVoice(session=sess,config=PiperConfig.from_dict(json.loads(Path(str(model)+'.json').read_text())))

CONFIG=SynthesisConfig(length_scale=1.12,noise_scale=0.5,noise_w_scale=0.65,volume=.85)

if __name__=='__main__':
    import wave,time
    v=load_voice();t=time.monotonic()
    with wave.open(str(ROOT/'voice-preview.wav'),'wb') as w:
        v.synthesize_wav('Let us slow this down. The product rule says: change the first factor and keep the second, then keep the first factor and change the second. We add these two contributions because both factors can change. Pause here and try the next step yourself.',w,syn_config=CONFIG)
    print('Voice preview generated in',round(time.monotonic()-t,1),'seconds')
